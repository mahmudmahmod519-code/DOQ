# DOQ (دوق) – Egyptian Street Food Carts Platform

**DOQ** is a web platform that connects customers with **street food carts** (عربيات أكل الشارع) across Egyptian cities.  
It is **NOT** home kitchens. The database table is still named `kitchens`, but the business meaning is **street food carts**.

---

## Core Idea

- Customers discover street food carts, view dishes, prices, ingredients, and leave reviews.
- Cart owners (chefs) manage their cart, dishes, and images.
- Admins have full control over users, categories, carts, dishes, and reviews.
- Smart ranking system called **Fair Score** (Bayesian Average) so new carts/dishes are not unfairly ranked low.

---

## Roles

| Role       | Meaning                                   |
|------------|-------------------------------------------|
| `customer` | Can browse, review dishes (once per dish) |
| `chef`     | Owns **one** cart only, manages his dishes|
| `admin`    | Full system control                       |
| Guest      | Can only browse public pages              |

---

## Tech Stack

- **Runtime**: Node.js + Express
- **Database**: MySQL (mysql2/promise)
- **Auth**: JWT stored in HttpOnly cookie (`session_token`)
- **Password**: bcrypt
- **Validation**: Joi
- **File Upload**: Multer
- **Templating**: EJS (server-side rendering)
- **Middleware chain**: `auth` → `for_main` → `roles` / `isOwner` / `allRows`

---

## Important Business Rules

1. A chef can create **only one cart**.
2. A customer can review a dish **only once**.
3. **Fair Score** formula (Bayesian Average):  
   ```
   (count * avg + 20 * 4.2) / (count + 20)
   ```
4. Most user-facing error messages are in **Arabic**.
5. Image paths sometimes use `/uploads/` and sometimes `/upload/` (known inconsistency).
6. API paths have slight inconsistency (`/v1/api` vs `/api/v1`).

---

## Project Structure

```
controller/     → Business logic
routes/         → Express routers
middlware/      → auth, roles, isOwner, allRows, for_main, upload, error
rendering/      → EJS render functions
utiles/         → validation, checker, catchError, isAuthenticated...
database/       → pool.js
views/          → EJS templates
public/upload/  → Uploaded images
```

---

## Folder Contents (This Package)

```
DOQ_Prompts/
├── README.md                          ← This file
├── docs/
│   └── API_OVERVIEW.md                ← Full API list + Fair Score explanation
└── prompts/
    ├── 01_auth_register.md
    ├── 02_auth_login.md
    ├── 03_auth_logout.md
    ├── 04_auth_me.md
    ├── 05_carts_list.md
    ├── 06_carts_get.md
    ├── 07_carts_create.md
    ├── 08_carts_update.md
    ├── 09_carts_delete.md
    ├── 10_dishes_list.md
    ├── 11_dishes_get.md
    ├── 12_dishes_create.md
    ├── 13_dishes_update.md
    ├── 14_dishes_delete.md
    ├── 15_reviews_create.md
    ├── 16_reviews_list.md
    ├── 17_categories.md
    ├── 18_admin_users.md
    ├── 19_admin_dashboard.md
    └── 20_upload_image.md
```

Every prompt file is **ready to copy-paste** into Cursor / Claude / ChatGPT / any AI coding tool to generate or review the corresponding API endpoint with full context.

---

## How to Use the Prompts

1. Open any file inside `prompts/`.
2. Copy the entire content.
3. Paste it into your AI coding assistant.
4. The AI will already know:
   - Project name & business rules
   - Tech stack
   - Role system
   - Fair Score formula
   - Arabic error messages preference
   - Middleware order
   - Image path inconsistencies to be aware of

---

## Fair Score (Quick Reference)

```js
function fairScore(count, average) {
  const C = 20;          // confidence constant
  const m = 4.2;         // prior mean
  return (count * average + C * m) / (count + C);
}
```

Used for ranking both **carts** and **dishes**.

---

Made with ❤️ for the Egyptian street food scene.  
دوق – لأن الأكل الشارعي يستحق منصة محترمة.
