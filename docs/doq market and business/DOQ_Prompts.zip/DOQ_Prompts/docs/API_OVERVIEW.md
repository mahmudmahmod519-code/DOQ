# DOQ – Complete API Overview

Base paths (note the known inconsistency):
- Preferred: `/api/v1`
- Sometimes appears as: `/v1/api`

All successful responses follow a common shape when possible:
```json
{
  "success": true,
  "message": "...",
  "data": { ... }
}
```

Error responses (mostly Arabic messages):
```json
{
  "success": false,
  "message": "رسالة الخطأ بالعربية"
}
```

---

## Authentication

| Method | Endpoint                  | Auth     | Roles          | Description                     |
|--------|---------------------------|----------|----------------|---------------------------------|
| POST   | /api/v1/auth/register     | Public   | -              | Register new customer or chef   |
| POST   | /api/v1/auth/login        | Public   | -              | Login → set HttpOnly cookie     |
| POST   | /api/v1/auth/logout       | Required | any            | Clear session cookie            |
| GET    | /api/v1/auth/me           | Required | any            | Get current user                |

---

## Carts (kitchens table)

| Method | Endpoint                  | Auth     | Roles          | Description                     |
|--------|---------------------------|----------|----------------|---------------------------------|
| GET    | /api/v1/carts             | Optional | any / guest    | List carts (with Fair Score)    |
| GET    | /api/v1/carts/:id         | Optional | any / guest    | Get single cart + dishes        |
| POST   | /api/v1/carts             | Required | chef           | Create cart (only one allowed)  |
| PUT    | /api/v1/carts/:id         | Required | chef (owner) / admin | Update cart               |
| DELETE | /api/v1/carts/:id         | Required | chef (owner) / admin | Delete cart               |

---

## Dishes

| Method | Endpoint                        | Auth     | Roles          | Description                     |
|--------|---------------------------------|----------|----------------|---------------------------------|
| GET    | /api/v1/dishes                  | Optional | any            | List dishes (filter by cart)    |
| GET    | /api/v1/dishes/:id              | Optional | any            | Get single dish + reviews       |
| POST   | /api/v1/dishes                  | Required | chef           | Create dish (own cart only)     |
| PUT    | /api/v1/dishes/:id              | Required | chef (owner) / admin | Update dish               |
| DELETE | /api/v1/dishes/:id              | Required | chef (owner) / admin | Delete dish               |

---

## Reviews

| Method | Endpoint                        | Auth     | Roles          | Description                     |
|--------|---------------------------------|----------|----------------|---------------------------------|
| POST   | /api/v1/reviews                 | Required | customer       | Create review (once per dish)   |
| GET    | /api/v1/reviews                 | Optional | any            | List reviews (by dish or cart)  |

---

## Categories

| Method | Endpoint                  | Auth     | Roles          | Description                     |
|--------|---------------------------|----------|----------------|---------------------------------|
| GET    | /api/v1/categories        | Public   | -              | List all categories             |
| POST   | /api/v1/categories        | Required | admin          | Create category                 |
| PUT    | /api/v1/categories/:id    | Required | admin          | Update category                 |
| DELETE | /api/v1/categories/:id    | Required | admin          | Delete category                 |

---

## Admin

| Method | Endpoint                  | Auth     | Roles          | Description                     |
|--------|---------------------------|----------|----------------|---------------------------------|
| GET    | /api/v1/admin/users       | Required | admin          | List all users                  |
| PUT    | /api/v1/admin/users/:id   | Required | admin          | Update user (role, ban...)      |
| DELETE | /api/v1/admin/users/:id   | Required | admin          | Delete user                     |
| GET    | /api/v1/admin/dashboard   | Required | admin          | Stats overview                  |

---

## Upload

| Method | Endpoint                  | Auth     | Roles          | Description                     |
|--------|---------------------------|----------|----------------|---------------------------------|
| POST   | /api/v1/upload            | Required | chef / admin   | Upload image (Multer)           |

---

## Fair Score Formula (used everywhere ranking is needed)

```js
const fairScore = (count, avg) => (count * avg + 20 * 4.2) / (count + 20);
```

- `count` = number of reviews
- `avg`   = average rating (1–5)
- Prior mean = 4.2
- Confidence constant = 20

This prevents new carts/dishes from ranking at the bottom just because they have few reviews.
