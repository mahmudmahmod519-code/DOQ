# Prompt: Auth – Register

You are working on the **DOQ (دوق)** platform – an Egyptian street food carts platform (عربيات أكل الشارع).  
Database table is still called `kitchens` but it means street food carts.  
Tech: Node.js + Express + MySQL (mysql2/promise) + JWT in HttpOnly cookie + bcrypt + Joi + Multer + EJS.

### Task
Implement the **POST /api/v1/auth/register** endpoint.

### Requirements
- Accept: `name`, `email`, `password`, `phone`, `role` (only `customer` or `chef` allowed – admin is created manually).
- Validate with Joi (strong password, valid email, Egyptian phone format preferred).
- Hash password with bcrypt (salt rounds 10 or 12).
- Check if email already exists → return Arabic error: `"البريد الإلكتروني مستخدم بالفعل"`.
- If role = `chef`, the user will later be allowed to create only **one** cart.
- On success: create user, return success message in Arabic + user data (without password).
- Do **NOT** auto-login. Client must call login after register.
- Use the existing middleware pattern and `catchError` utility.
- Most error messages must be in Arabic.

### Expected Response Shapes
Success:
```json
{
  "success": true,
  "message": "تم إنشاء الحساب بنجاح",
  "data": { "id": 1, "name": "...", "email": "...", "role": "customer" }
}
```

Error examples:
- `"البريد الإلكتروني مستخدم بالفعل"`
- `"كلمة المرور ضعيفة"`
- `"الدور غير مسموح"`

### Context Reminders
- Middleware order: auth → for_main → roles / isOwner / allRows
- JWT goes into HttpOnly cookie named `session_token`
- Image paths sometimes use `/uploads/` and sometimes `/upload/` (be aware)

Write clean, production-ready controller + route + validation schema.