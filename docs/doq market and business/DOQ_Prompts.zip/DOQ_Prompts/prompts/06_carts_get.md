# Prompt: Carts – Get Single Cart

You are working on **DOQ (دوق)**.

### Task
Implement **GET /api/v1/carts/:id**.

### Requirements
- Public endpoint.
- Return full cart details + list of its dishes (with their own fair scores).
- Include owner info (name only, no sensitive data).
- Include average rating, review count, and calculated Fair Score for the cart.
- If cart not found → Arabic: `"العربة غير موجودة"`.
- Optionally include recent reviews.

Use the Fair Score formula:
`(count * avg + 20 * 4.2) / (count + 20)`