# Prompt: Dishes – Get Single Dish

You are working on **DOQ (دوق)**.

### Task
Implement **GET /api/v1/dishes/:id**.

### Requirements
- Public.
- Return full dish details + its reviews + calculated Fair Score.
- Include parent cart basic info.
- Not found → `"الطبق غير موجود"`.