# Prompt: Dishes – Update Dish

You are working on **DOQ (دوق)**.

### Task
Implement **PUT /api/v1/dishes/:id**.

### Requirements
- Owner chef or admin only (`isOwner` middleware).
- Partial update allowed.
- Validate with Joi.
- Arabic success/error messages.