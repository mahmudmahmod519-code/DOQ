# Prompt: Dishes – List Dishes

You are working on **DOQ (دوق)**.

### Task
Implement **GET /api/v1/dishes**.

### Requirements
- Public / optional auth.
- Query params: `cart_id`, `category_id`, `search`, `page`, `limit`, `sort`.
- When sorting by rating, use Fair Score:
  `(count * avg + 20 * 4.2) / (count + 20)`
- Return dish name, price, ingredients, image, fair_score, cart name, etc.
- Paginated.