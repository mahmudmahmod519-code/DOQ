# Prompt: Admin – Users Management

You are working on **DOQ (دوق)**.

### Task
Implement admin user management:

- GET    /api/v1/admin/users
- PUT    /api/v1/admin/users/:id
- DELETE /api/v1/admin/users/:id

### Requirements
- Only role `admin`.
- List users with filters (role, search, pagination).
- Update: change role, ban/unban, edit name/phone...
- Delete carefully (consider related data).
- All messages in Arabic.