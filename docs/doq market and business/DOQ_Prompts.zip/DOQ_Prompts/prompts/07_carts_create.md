# Prompt: Carts – Create Cart

You are working on **DOQ (دوق)**.

### Critical Business Rule
A chef can create **only one cart**.  
If the chef already has a cart → reject with Arabic message: `"لديك عربة بالفعل، لا يمكنك إنشاء أكثر من عربة واحدة"`.

### Task
Implement **POST /api/v1/carts**.

### Requirements
- Protected: only role `chef` (or admin).
- Accept: name, description, city, address, category_id, phone, image (optional), working_hours...
- Validate with Joi.
- Check that the current chef does not already own a cart.
- Insert into `kitchens` table (remember the table name is still kitchens).
- Return the created cart.
- Success message in Arabic: `"تم إنشاء العربة بنجاح"`.

Use `isOwner` or role middleware appropriately.