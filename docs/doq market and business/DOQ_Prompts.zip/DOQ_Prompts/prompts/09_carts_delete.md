# Prompt: Carts – Delete Cart

You are working on **DOQ (دوق)**.

### Task
Implement **DELETE /api/v1/carts/:id**.

### Requirements
- Only owner chef or admin.
- Soft delete preferred if the project supports it, otherwise hard delete.
- Consider cascading: what happens to dishes and reviews? (decide or follow existing pattern).
- Arabic messages:
  - Success: `"تم حذف العربة بنجاح"`
  - Not found / not owner: appropriate Arabic message.

Use existing middleware chain.