# Prompt: Admin – Dashboard Stats

You are working on **DOQ (دوق)**.

### Task
Implement **GET /api/v1/admin/dashboard**.

### Requirements
- Admin only.
- Return useful stats:
  - Total users (by role)
  - Total carts
  - Total dishes
  - Total reviews
  - Average platform rating
  - New carts this month
  - Top carts by Fair Score
  - Recent activity
- Keep it efficient (use aggregation queries).