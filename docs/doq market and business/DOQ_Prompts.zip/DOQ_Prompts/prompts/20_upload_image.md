# Prompt: Upload Image

You are working on **DOQ (دوق)**.

### Task
Implement **POST /api/v1/upload** (or the path the project uses).

### Requirements
- Protected (chef or admin).
- Use Multer.
- Accept single image (jpeg, png, webp).
- Size limit (e.g. 2–5 MB).
- Store in `public/upload/` or `public/uploads/` (note the known inconsistency in the project).
- Return the public path of the uploaded file.
- Arabic error messages for invalid type / size.

### Response Example
```json
{
  "success": true,
  "message": "تم رفع الصورة بنجاح",
  "data": {
    "url": "/upload/1725xxxxx-dish.jpg"
  }
}
```

Be aware that some parts of the codebase use `/uploads/` and others `/upload/`.