# Prompt: Dishes – Create Dish

You are working on **DOQ (دوق)**.

### Task
Implement **POST /api/v1/dishes**.

### Requirements
- Only chef (must own the cart) or admin.
- Accept: name, description, price, ingredients, image, cart_id (or auto from chef’s cart), category_id...
- Validate price > 0, required fields.
- Chef can only add dishes to **his own** cart.
- Success message: `"تم إضافة الطبق بنجاح"`.