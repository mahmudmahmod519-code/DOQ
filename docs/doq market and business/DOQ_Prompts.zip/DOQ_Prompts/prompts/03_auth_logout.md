# Prompt: Auth – Logout

You are working on **DOQ (دوق)** – Egyptian street food carts platform.

### Task
Implement **POST /api/v1/auth/logout** (or GET if the project prefers).

### Requirements
- Requires authentication (any logged-in user).
- Clear the `session_token` HttpOnly cookie (set maxAge to 0 or use clearCookie).
- Return Arabic success message: `"تم تسجيل الخروج بنجاح"`.
- No need to blacklist the JWT if the project is not using a blacklist (cookie clearing is enough for this stage).

### Response
```json
{
  "success": true,
  "message": "تم تسجيل الخروج بنجاح"
}
```

Keep it simple and consistent with the rest of the auth module.