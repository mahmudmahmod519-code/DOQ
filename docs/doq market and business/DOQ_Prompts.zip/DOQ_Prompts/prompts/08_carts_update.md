# Prompt: Carts – Update Cart

You are working on **DOQ (دوق)**.

### Task
Implement **PUT /api/v1/carts/:id** (or PATCH).

### Requirements
- Protected.
- Only the owner chef **or** admin can update.
- Use `isOwner` middleware (or equivalent).
- Accept partial updates: name, description, city, image, working_hours, etc.
- Validate with Joi.
- If not found or not owner → proper Arabic error.
- Success: `"تم تحديث العربة بنجاح"`.

Remember image path inconsistency (`/uploads/` vs `/upload/`).