# Prompt: Reviews – List Reviews

You are working on **DOQ (دوق)**.

### Task
Implement **GET /api/v1/reviews**.

### Requirements
- Public.
- Query params: `dish_id`, `cart_id`, `user_id`, `page`, `limit`.
- Return reviews with user name, rating, comment, created_at.
- Sorted by newest first (or by rating).