# Prompt: Categories CRUD

You are working on **DOQ (دوق)**.

### Task
Implement full Categories endpoints:

- GET    /api/v1/categories          → Public list
- POST   /api/v1/categories          → Admin only
- PUT    /api/v1/categories/:id      → Admin only
- DELETE /api/v1/categories/:id      → Admin only

### Requirements
- Simple name + optional image/icon.
- Arabic messages.
- Prevent deleting a category that still has carts/dishes if the project requires it.