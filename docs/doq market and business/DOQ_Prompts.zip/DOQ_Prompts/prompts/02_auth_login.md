# Prompt: Auth – Login

You are working on the **DOQ (دوق)** platform – Egyptian street food carts (عربيات أكل الشارع).  
Tech: Node.js + Express + MySQL + JWT (HttpOnly cookie `session_token`) + bcrypt + Joi.

### Task
Implement **POST /api/v1/auth/login**.

### Requirements
- Accept: `email` + `password`.
- Validate with Joi.
- Find user by email.
- If not found or password wrong → Arabic message: `"بيانات الدخول غير صحيحة"` (do not reveal which one is wrong).
- Compare password with bcrypt.
- Generate JWT containing at least: `id`, `role`, `email` (or whatever the project already uses).
- Set the token in an **HttpOnly**, Secure (in production), SameSite cookie named `session_token`.
- Return user data (without password) + success message in Arabic.
- Optional: update `last_login` if the column exists.

### Expected Response
```json
{
  "success": true,
  "message": "تم تسجيل الدخول بنجاح",
  "data": {
    "id": 1,
    "name": "أحمد",
    "email": "ahmed@example.com",
    "role": "chef"
  }
}
```

### Security Notes
- Never return the password hash.
- Cookie must be HttpOnly.
- Clear any previous session if needed.

Use existing utilities (`catchError`, validation, etc.).