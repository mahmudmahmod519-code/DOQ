# Prompt: Carts – List All Carts

You are working on **DOQ (دوق)** – street food carts platform (table name is still `kitchens`).

### Task
Implement **GET /api/v1/carts**.

### Requirements
- Public / optional auth (guests can browse).
- Support query params: `page`, `limit`, `city`, `category_id`, `search`, `sort`.
- Default sort should use **Fair Score** (highest first).
- Fair Score formula (must implement exactly):
  ```js
  (count * avg + 20 * 4.2) / (count + 20)
  ```
- Return for each cart: id, name, description, city, image, average rating, review count, fair_score, owner name, category...
- Paginated response.
- Arabic messages when needed.

### Response Shape
```json
{
  "success": true,
  "data": {
    "carts": [ ... ],
    "pagination": { "page": 1, "limit": 12, "total": 48, "pages": 4 }
  }
}
```

Remember: this is the main discovery endpoint for customers.