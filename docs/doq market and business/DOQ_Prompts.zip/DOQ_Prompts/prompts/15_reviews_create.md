# Prompt: Reviews – Create Review

You are working on **DOQ (دوق)**.

### Critical Business Rule
A customer can review a dish **only once**.

### Task
Implement **POST /api/v1/reviews**.

### Requirements
- Only role `customer`.
- Accept: `dish_id`, `rating` (1-5), `comment` (optional).
- Check if the user already reviewed this dish → reject with:
  `"لقد قمت بتقييم هذا الطبق من قبل"`.
- After insert, recalculate the dish’s average rating and review count (or rely on Fair Score calculation on the fly).
- Success: `"تم إضافة التقييم بنجاح"`.

This endpoint is very important for the Fair Score system.