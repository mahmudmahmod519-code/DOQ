# Prompt: Dishes – Delete Dish

You are working on **DOQ (دوق)**.

### Task
Implement **DELETE /api/v1/dishes/:id**.

### Requirements
- Owner chef or admin.
- Decide soft vs hard delete according to project convention.
- Handle related reviews if necessary.
- Arabic messages.