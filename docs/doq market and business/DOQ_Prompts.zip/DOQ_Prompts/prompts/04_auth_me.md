# Prompt: Auth – Get Current User (Me)

You are working on **DOQ (دوق)** platform.

### Task
Implement **GET /api/v1/auth/me**.

### Requirements
- Protected route (must have valid `session_token` cookie).
- Return the currently authenticated user (id, name, email, phone, role, created_at...).
- Do **not** return the password hash.
- If the user has a cart (role = chef), optionally include basic cart info (id + name) if it exists.
- Arabic error if not authenticated: `"يجب تسجيل الدخول أولاً"`.

### Response Example
```json
{
  "success": true,
  "data": {
    "id": 5,
    "name": "محمد الشيف",
    "email": "chef@doq.com",
    "role": "chef",
    "cart": { "id": 12, "name": "عربة الكبدة الأصلية" }
  }
}
```

Use the existing `auth` middleware.